CharSequence::CharSequence(const char* str) : ::java::lang::Object(java::lang::String(str)) { __Initialize(); }

void CharSequence::__Initialize() { }
