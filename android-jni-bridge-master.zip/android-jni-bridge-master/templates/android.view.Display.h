jint __GetRawWidth() const;
jint __GetRawHeight() const;
