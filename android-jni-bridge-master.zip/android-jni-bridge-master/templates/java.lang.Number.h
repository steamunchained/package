
operator ::jbyte() const;
operator ::jshort() const;
operator ::jint() const;
operator ::jlong() const;
operator ::jfloat() const;
operator ::jdouble() const;
