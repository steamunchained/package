CharSequence(const char* str);
